
import { useRouter } from 'next/router'
import { useEffect, useState } from 'react'
import axios from 'axios'

export default function Chapter() {
  const router = useRouter()
  const { id } = router.query
  const [images, setImages] = useState([])

  useEffect(() => {
    if(!id) return
    const fetchImages = async () => {
      const res = await axios.get(`/api/chapterImages?chapterId=${id}`)
      const baseUrl = res.data.baseUrl
      const pages = res.data.chapter.data.map(filename => `${baseUrl}/data/${res.data.chapter.hash}/${filename}`)
      setImages(pages)
    }
    fetchImages()
  }, [id])

  if(images.length === 0) return <p>Loading...</p>

  return (
    <div>
      {images.map((img, i) => (
        <img key={i} src={img} alt={`Page ${i+1}`} style={{width: '100%'}}/>
      ))}
    </div>
  )
}
