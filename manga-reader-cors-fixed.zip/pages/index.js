
import { useState } from 'react'
import axios from 'axios'
import Link from 'next/link'

export default function Home() {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState([])

  const searchManga = async () => {
    const res = await axios.get(`/api/manga?query=${query}`)
    setResults(res.data.data)
  }

  return (
    <div>
      <h1>MangaDex Reader</h1>
      <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search manga"/>
      <button onClick={searchManga}>Search</button>
      <div>
        {results.map(manga => (
          <Link key={manga.id} href={`/manga/${manga.id}`}>
            <a>{manga.attributes.title.en || 'No Title'}</a>
          </Link>
        ))}
      </div>
    </div>
  )
}
