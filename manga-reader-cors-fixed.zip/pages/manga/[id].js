
import { useRouter } from 'next/router'
import { useEffect, useState } from 'react'
import axios from 'axios'
import Link from 'next/link'

export default function Manga() {
  const router = useRouter()
  const { id } = router.query
  const [manga, setManga] = useState(null)
  const [chapters, setChapters] = useState([])

  useEffect(() => {
    if(!id) return
    const fetchManga = async () => {
      const res = await axios.get(`https://api.mangadex.org/manga/${id}`)
      setManga(res.data.data)
      const chRes = await axios.get(`/api/chapters?mangaId=${id}`)
      setChapters(chRes.data.data)
    }
    fetchManga()
  }, [id])

  if(!manga) return <p>Loading...</p>

  return (
    <div>
      <h1>{manga.attributes.title.en}</h1>
      <p>{manga.attributes.description.en}</p>
      <h2>Chapters</h2>
      <ul>
        {chapters.map(ch => (
          <li key={ch.id}>
            <Link href={`/chapter/${ch.id}`}>{ch.attributes.chapter} - {ch.attributes.title}</Link>
          </li>
        ))}
      </ul>
    </div>
  )
}
